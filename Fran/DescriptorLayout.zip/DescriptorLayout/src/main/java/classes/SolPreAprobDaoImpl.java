package classes;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;
import oracle.sql.ARRAY;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import classes.TypeColumns;

public class SolPreAprobDaoImpl implements SolPreApropDao {

	String urlDesarrollo = "jdbc:oracle:thin:@10.63.32.230:1521:CRCBDDES";
	String user = "USRAPPCRDA";
	String password = "MXc35yd_45D3";
	String schema = "SC_SOLCRDA";
	String catalogo = "pa_preaprobados";
	String stored = "spiudpreaprobad";

	public HashMap<String, Object> consultaSolicitudes(ARRAY parametros) {
		OracleDataSource oracleDS = null;
		HashMap<String, Object> result = new HashMap<String, Object>();
		try {
			oracleDS = new OracleDataSource();
			oracleDS.setURL(urlDesarrollo);
			oracleDS.setUser(user);
			oracleDS.setPassword(password);

			SimpleJdbcCall jdbCall = new SimpleJdbcCall(oracleDS);

			Map<String, Object> results = null;

			jdbCall.withSchemaName(schema).withCatalogName(catalogo).withProcedureName(stored)
			.declareParameters(
					new SqlParameter("ptab_datos", OracleTypes.ARRAY),
					new SqlOutParameter("pcur_fallidos",OracleTypes.CURSOR, new RowMapper<Object>() {
						public Object mapRow(ResultSet rs, int argl) throws SQLException {
							TypeColumnsCursor cursor = new TypeColumnsCursor();
							cursor.setTyppais(rs.getInt("typpais"));
							cursor.setTypcanal(rs.getInt("typcanal"));
							cursor.setTypsucursal(rs.getInt("typsucursal"));
							cursor.setTypfolio(rs.getInt("typfolio"));
							cursor.setTypcampania(rs.getInt("typcampania"));
							cursor.setTypplazo(rs.getInt("typplazo"));
							cursor.setTypcredito(rs.getInt("typcredito"));
							cursor.setTypabononormal(rs.getInt("typabononormal"));
							cursor.setTypabonopuntual(rs.getInt("typabonopuntual"));
							cursor.setTypstatus(rs.getInt("typstatus"));
							cursor.setTypvigenciaprom(rs.getDate("typvigenciaprom"));
							cursor.setTypoperacion(rs.getInt("typoperacion"));
							cursor.setTypmessage(rs.getString("typmessage"));
							return cursor;
						}
					}),
				new SqlOutParameter("pa_resultado", OracleTypes.INTEGER),
				new SqlOutParameter("pa_mensaje", OracleTypes.VARCHAR));
			results = jdbCall.execute(new MapSqlParameterSource().addValue("ptab_datos",parametros,OracleTypes.ARRAY));
			return result;

		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}

}
