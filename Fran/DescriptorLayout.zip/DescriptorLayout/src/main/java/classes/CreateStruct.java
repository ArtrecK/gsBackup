package classes;

import classes.TypeColumns;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import oracle.jdbc.pool.OracleDataSource;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

public class CreateStruct {
	
	static Connection con = null;
	static ArrayList<TypeColumns> arrayPreAprob;
	static OracleDataSource oracleDS = null;
	static String urlDesarrollo = "jdbc:oracle:thin:@10.63.32.230:1521:CRCBDDES";
	static String user = "USRAPPCRDA";
	static String password = "MXc35yd_45D3";
	String schema = "SC_SOLCRDA";
	String catalogo = "pa_preaprobados";
	String stored = "spiudpreaprobad";
	
	public CreateStruct(ArrayList<TypeColumns> arrayPreAprob) {
		CreateStruct.arrayPreAprob = arrayPreAprob;
	}
	
	public static ArrayList<TypeColumns> returnArray(){
		return arrayPreAprob;
	}
	
	public static void createDescriptor() throws SQLException {
		ArrayList<TypeColumns> arrayPreAprob = new ArrayList<TypeColumns>();
		TypeColumns element = new TypeColumns();
		element.typpais=1;
		element.typcanal=1;
		element.typsucursal=100;
		element.typfolio=52;
		element.typcampania=1;
		element.typplazo=1;
		element.typcredito=8000;
		
		arrayPreAprob.add(element);	
		
		oracleDS = new OracleDataSource();
		oracleDS.setURL(urlDesarrollo);
		oracleDS.setUser(user);
		oracleDS.setPassword(password);
		
		con=oracleDS.getConnection();
		
		ARRAY arrParametros = null;
		StructDescriptor structDesc = StructDescriptor.createDescriptor("sc_solcrda.pa_preaprobados.vgtab_preap",con);
		ArrayList<STRUCT> arrStr = new ArrayList<>();
		Object[] arrObj = new Object[structDesc.getLength()]; 
		for (TypeColumns tyCol: arrayPreAprob) {
			arrObj[0]=tyCol.getTyppais();
			arrObj[1]=tyCol.getTypsucursal();
			arrObj[2]=tyCol.getTypfolio();
			arrObj[3]=tyCol.getTypcampania();
			arrObj[4]=tyCol.getTypplazo();
			arrObj[5]=tyCol.getTypcredito();
			arrObj[6]=tyCol.getTypabononormal();
			arrObj[7]=tyCol.getTypabonopuntual();
			arrObj[8]=tyCol.getTypstatus();
			arrObj[9]=tyCol.getTypvigenciaprom();
			arrObj[10]=tyCol.getTypoperacion();
			STRUCT struct = new STRUCT(structDesc,con,arrObj);
			arrStr.add(struct);
		}
		ArrayDescriptor arrDesc = ArrayDescriptor.createDescriptor("sc_solcrda.pa_preaprobados.vgtab_preap",con);
		STRUCT[] structcan = new STRUCT[arrayPreAprob.size()];
		structcan = arrStr.toArray(structcan);	
		arrParametros = new ARRAY(arrDesc, con, structcan);
	}
	
}
