package classes;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

import classes.CreateStruct;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

public class Mainclass {

	static Connection con = null;
	static ArrayList<TypeColumns> arrayPreAprob;
	static OracleDataSource oracleDS = null;
	static String urlDesarrollo = "jdbc:oracle:thin:@10.82.59.28:4410:CMBDINT";
	static String user = "USRAPPCRDA";
	static String password = "MXc35yd_45D3";
	String schema = "SC_SOLCRDA";
	String catalogo = "pa_preaprobados";
	String stored = "spiudpreaprobad";
	
	//public ArrayList<TypeColumns> arrayPreAprob() {
	//	arrayPreAprob = arrayPreAprob;
	//}
	
	public static ArrayList<TypeColumns> returnArray(){
		return arrayPreAprob;
	}
	
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		//CreateStruct class = new CreateStruct();

		ArrayList<TypeColumns> arrayPreAprob = new ArrayList<TypeColumns>();
		TypeColumns element = new TypeColumns();
		Date today = new Date(0, 0, 0); 
		element.typpais=1;
		element.typcanal=1;
		element.typsucursal=100;
		element.typfolio=52;
		element.typcampania=4;
		element.typplazo=1;
		element.typcredito=8000;
		element.typabononormal=1;
		element.typabonopuntual=232;
		element.typstatus=1;
		element.typvigenciaprom=today;
		element.typoperacion=1; //Always insert
		
		arrayPreAprob.add(element);	
		
		oracleDS = new OracleDataSource();
		oracleDS.setURL(urlDesarrollo);
		oracleDS.setUser(user);
		oracleDS.setPassword(password);
		
		con=oracleDS.getConnection();
		
		ARRAY arrParametros = null;
		
		//OracleCallableStatement cstmt = (OracleCallableStatement)con.prepareCall("{ ? = call pa_preaprobados.your_function}"); ;
		//cstmt.registerOutParameter(1, OracleTypes.JAVA_STRUCT, "SC_SOLCRDA.pa_preaprobados.vgrec_preap");
		
		StructDescriptor structDesc = StructDescriptor.createDescriptor("SC_SOLCRDA.vgtab_preap",con);
		ArrayList<STRUCT> arrStr = new ArrayList<>();
		Object[] arrObj = new Object[structDesc.getLength()]; 
		for (TypeColumns tyCol: arrayPreAprob) {
			arrObj[0]=tyCol.getTyppais();
			arrObj[1]=tyCol.getTypcanal();
			arrObj[2]=tyCol.getTypsucursal();
			arrObj[3]=tyCol.getTypfolio();
			arrObj[4]=tyCol.getTypcampania();
			arrObj[5]=tyCol.getTypplazo();
			arrObj[6]=tyCol.getTypcredito();
			arrObj[7]=tyCol.getTypabononormal();
			arrObj[8]=tyCol.getTypabonopuntual();
			arrObj[9]=tyCol.getTypstatus();
			arrObj[10]=tyCol.getTypvigenciaprom();
			arrObj[11]=tyCol.getTypoperacion();
			STRUCT struct = new STRUCT(structDesc,con,arrObj);
			arrStr.add(struct);
		}
		ArrayDescriptor arrDesc = ArrayDescriptor.createDescriptor("SC_SOLCRDA.pa_preaprobados.vgrec_preap",con);
		STRUCT[] structcan = new STRUCT[arrayPreAprob.size()];
		structcan = arrStr.toArray(structcan);	
		arrParametros = new ARRAY(arrDesc, con, structcan);
		
	}

}
