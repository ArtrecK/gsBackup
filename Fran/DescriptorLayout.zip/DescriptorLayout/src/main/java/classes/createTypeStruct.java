package classes;

import java.util.ArrayList;

public class createTypeStruct {
	
	protected ArrayList<TypeColumns> arrayPreAprob;
	
	public createTypeStruct(ArrayList<TypeColumns> arrayPreAprob) {
		CreateStruct.arrayPreAprob = arrayPreAprob;
	}
	
	public ArrayList<TypeColumns> getArrayPreAprob() {
		return arrayPreAprob;
	}

	public void setArrayPreAprob(ArrayList<TypeColumns> arrayPreAprob) {
		this.arrayPreAprob = arrayPreAprob;
	}
	
	public ArrayList<TypeColumns> returnArray(){
		return arrayPreAprob;
	}
	
	

}
