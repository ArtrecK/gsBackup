package classes;

import java.util.HashMap;

import oracle.sql.ARRAY;

public interface SolPreApropDao {
	public HashMap<String, Object> consultaSolicitudes(ARRAY parametros);
}
