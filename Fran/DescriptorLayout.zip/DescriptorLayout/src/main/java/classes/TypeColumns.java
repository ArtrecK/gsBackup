package classes;

import java.sql.Date;

public class TypeColumns {

	int typpais;
	int typcanal;
	int typsucursal;
	int typfolio;
	int typcampania;
	int typplazo;
	int typcredito;
	int typabononormal;
	int typabonopuntual;
	int typstatus;
	Date typvigenciaprom;
	int typoperacion;
	
	public int getTyppais() {
		return typpais;
	}
	public int getTypcanal() {
		return typcanal;
	}
	public void setTypcanal(int typcanal) {
		this.typcanal = typcanal;
	}
	public void setTyppais(int typpais) {
		this.typpais = typpais;
	}
	public int getTypsucursal() {
		return typsucursal;
	}
	public void setTypsucursal(int typsucursal) {
		this.typsucursal = typsucursal;
	}
	public int getTypfolio() {
		return typfolio;
	}
	public void setTypfolio(int typfolio) {
		this.typfolio = typfolio;
	}
	public int getTypcampania() {
		return typcampania;
	}
	public void setTypcampania(int typcampania) {
		this.typcampania = typcampania;
	}
	public int getTypplazo() {
		return typplazo;
	}
	public void setTypplazo(int typplazo) {
		this.typplazo = typplazo;
	}
	public int getTypcredito() {
		return typcredito;
	}
	public void setTypcredito(int typcredito) {
		this.typcredito = typcredito;
	}
	public int getTypabononormal() {
		return typabononormal;
	}
	public void setTypabononormal(int typabononormal) {
		this.typabononormal = typabononormal;
	}
	public int getTypabonopuntual() {
		return typabonopuntual;
	}
	public void setTypabonopuntual(int typabonopuntual) {
		this.typabonopuntual = typabonopuntual;
	}
	public int getTypstatus() {
		return typstatus;
	}
	public void setTypstatus(int typstatus) {
		this.typstatus = typstatus;
	}
	public Date getTypvigenciaprom() {
		return typvigenciaprom;
	}
	public void setTypvigenciaprom(Date typvigenciaprom) {
		this.typvigenciaprom = typvigenciaprom;
	}
	public int getTypoperacion() {
		return typoperacion;
	}
	public void setTypoperacion(int typoperacion) {
		this.typoperacion = typoperacion;
	}
	
	
}
