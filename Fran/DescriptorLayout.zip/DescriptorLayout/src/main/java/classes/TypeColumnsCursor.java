package classes;

public class TypeColumnsCursor extends TypeColumns{

	String typmessage;

	public String getTypmessage() {
		return typmessage;
	}

	public void setTypmessage(String typmessage) {
		this.typmessage = typmessage;
	}
	
}
